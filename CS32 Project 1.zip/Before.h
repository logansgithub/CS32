#pragma once
#ifndef Before_h
#define Before_h
#include "globals.h"

class Before {
public:
	//constructor & functions to be used in this class
	Before(int nRows, int nCols);
	bool keepTrack(int r, int c);
	void printWhatWasBefore() const;

private:
	int m_rows; //member variables
	int m_cols;
	char timesLanded[MAXROWS][MAXCOLS]; //to keep track of times landed
};


#endif // !Before_h
