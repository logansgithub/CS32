#include "Before.h"
#include <iostream>
using namespace std;


Before::Before(int nRows, int nCols) {
	m_rows = nRows;
	m_cols = nCols;

	//initialize constructor to be all dots
	for (int r = 0; r < m_rows; r++) {
		for (int c = 0; c < m_cols; c++) {
			timesLanded[r][c] = '.';
		}
	}
}


bool Before::keepTrack(int r, int c) {
	int m_row = r-1;
	int m_col = c-1;
	//first parameter for keepTrack function
	if (r<0 || r>MAXROWS || c<0 || c>MAXCOLS) {
		return false;
	}

	//function returns true if variables are valid values
	//function keeps track of times landed for each space and adjusts
	if (timesLanded[m_row][m_col] == '.')// && Player.row() == m_row && Player.col() == m_col) 
	{
		timesLanded[m_row][m_col] = 'A';
		return true;
	}

	else if (timesLanded[m_row][m_col] == 'Z')//&& Player.row() == m_row && Player.col() == m_col)
	{
		return true;
	}

	else //if (timesLanded[m_row][m_col] < 'Z' || timesLanded[m_row][m_col] >= 'A')//&& Player.row() == m_row && Player.col() == m_col) {
	{
		timesLanded[m_row][m_col] ++;
	}
	return true;
}


void Before::printWhatWasBefore() const {
	//function clears screen
	clearScreen();
	//function prints the recorded times landed
	for (int r = 0; r < m_rows; r++) {
		for (int c = 0; c < m_cols; c++) {
			
			cout << timesLanded[r][c];
		}
		cout << endl;
	}
	return;
}
